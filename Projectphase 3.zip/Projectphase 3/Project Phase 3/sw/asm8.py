#!/usr/bin/env python3
import sys, re

OPS = {
    "NOP":0x0, "ADD":0x1, "SUB":0x2, "AND":0x3, "OR":0x4,  "XOR":0x5,
    "SHL":0x6, "SHR":0x7, "LDI":0x8, "ADDI":0x9,"LD":0xA,  "ST":0xB,
    "JMP":0xC, "BZ":0xD,  "BNZ":0xE, "HLT":0xF
}

def reg(t):
    t = t.strip("[] ").upper()
    if not t.startswith("R"): raise ValueError(f"Bad reg: {t}")
    r = int(t[1:])
    if not 0 <= r <= 7: raise ValueError(f"Reg out of range: {t}")
    return r

def num(t, labels):
    t = t.strip()
    if t in labels: return labels[t]
    return int(t, 0)

def assemble(text):
    src = []
    labels = {}
    for raw in text.splitlines():
        ln = raw.split(";")[0].strip()
        if not ln: continue
        if ln.endswith(":"):
            labels[ln[:-1].strip()] = len(src)
            continue
        if ":" in ln:
            lbl, rest = ln.split(":", 1)
            labels[lbl.strip()] = len(src)
            ln = rest.strip()
            if not ln: continue
        src.append(ln)

    words = []
    for pc, ln in enumerate(src):
        parts = [p.strip() for p in re.split(r"[,\s]+", ln, maxsplit=1)]
        mn = parts[0].upper()
        ops = [x.strip() for x in parts[1].split(",")] if len(parts) > 1 and parts[1] else []
        op = OPS[mn]
        if mn in ("NOP", "HLT"):
            w = (op << 12)
        elif mn in ("ADD", "SUB", "AND", "OR", "XOR"):
            rd, rs1, rs2 = reg(ops[0]), reg(ops[1]), reg(ops[2])
            w = (op << 12) | (rd << 9) | (rs1 << 6) | (rs2 << 3)
        elif mn in ("SHL", "SHR"):
            rd, rs1 = reg(ops[0]), reg(ops[1])
            sh = num(ops[2], labels) & 0x7
            w = (op << 12) | (rd << 9) | (rs1 << 6) | (sh << 3)
        elif mn in ("LDI", "ADDI"):
            rd = reg(ops[0])
            imm = num(ops[1], labels) & 0xFF
            w = (op << 12) | (rd << 9) | imm
        elif mn == "LD":
            rd, rs1 = reg(ops[0]), reg(ops[1])
            w = (op << 12) | (rd << 9) | (rs1 << 6)
        elif mn == "ST":
            rs2, rs1 = reg(ops[0]), reg(ops[1])
            w = (op << 12) | (rs1 << 6) | (rs2 << 3)
        elif mn in ("JMP", "BZ", "BNZ"):
            addr = num(ops[0], labels) & 0xFF
            w = (op << 12) | addr
        else:
            raise ValueError(f"Unknown op: {mn}")
        words.append(w)
    return words

if __name__ == "__main__":
    inp = sys.argv[1]
    out = sys.argv[2]
    words = assemble(open(inp).read())
    with open(out, "w") as f:
        for w in words:
            f.write(f"{w:04x}\n")
    print(f"Assembled {len(words)} words -> {out}")
