; Part A: Read PERIPH_ID (0xFF) -> Store to DMEM[0x80]
        LDI  R7, 0xFF
        LD   R1, [R7]
        LDI  R6, 0x80
        ST   R1, [R6]

; Part B: Configure SAR ADC on Channel 1, Trigger & Poll FIFO
        LDI  R7, 0xF6       ; ADC_SMP = 3
        LDI  R1, 3
        ST   R1, [R7]
        LDI  R7, 0xF7       ; ADC_DIV = 0
        LDI  R1, 0
        ST   R1, [R7]
        LDI  R7, 0xF5       ; ADC_CTRL: EN=1, START=1, CH=1 (0x13)
        LDI  R1, 0x13
        ST   R1, [R7]

        LDI  R7, 0xFC       ; ADC_STAT
        LDI  R2, 0x10       ; EMPTY mask (bit 4)
wait_b:
        LD   R1, [R7]
        AND  R1, R1, R2
        BNZ  wait_b

        LDI  R7, 0xFB       ; ADC_RCH -> DMEM[0x81]
        LD   R1, [R7]
        LDI  R6, 0x81
        ST   R1, [R6]

        LDI  R7, 0xFA       ; ADC_DATA -> DMEM[0x82]
        LD   R1, [R7]
        LDI  R6, 0x82
        ST   R1, [R6]
        HLT
