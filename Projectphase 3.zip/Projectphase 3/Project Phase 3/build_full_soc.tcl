# Run in Vivado Tcl Console: source build_full_soc.tcl
create_project risc8_soc_full ./vivado_soc_proj -part xc7a35tcpg236-1 -force

add_files -fileset sources_1 [glob ./rtl/*.v]
add_files -fileset sim_1 [glob ./tb/*.v]
add_files -fileset sim_1 [glob ./uvm/*.sv]
add_files -fileset sim_1 ./sw/soc_demo.hex

set_property top risc8_soc [current_fileset]
set_property top tb_risc8_soc [get_filesets sim_1]

update_compile_order -fileset sources_1
update_compile_order -fileset sim_1

launch_simulation
run all
