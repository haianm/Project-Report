# Run in Vivado Tcl Console after build_full_soc.tcl to switch to UVM Testbench
set_property top tb_timer_adc_uvm [get_filesets sim_1]
update_compile_order -fileset sim_1
launch_simulation
run all
