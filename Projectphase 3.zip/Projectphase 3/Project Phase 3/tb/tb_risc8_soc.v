`timescale 1ns/1ps

module tb_risc8_soc;
    reg        clk;
    reg        rst;
    wire       halted;
    wire [7:0] pc_out;
    wire       irq;
    wire       pwm_out;
    wire       adc_sample;
    wire [1:0] adc_ch;
    wire [7:0] adc_dac;
    wire       adc_cmp;

    integer pass_count = 0;
    integer fail_count = 0;

    risc8_soc dut (
        .clk(clk),
        .rst(rst),
        .halted(halted),
        .pc_out(pc_out),
        .irq(irq),
        .pwm_out(pwm_out),
        .adc_sample(adc_sample),
        .adc_ch(adc_ch),
        .adc_dac(adc_dac),
        .adc_cmp(adc_cmp)
    );

    afe_model u_afe (
        .sample(adc_sample),
        .ch(adc_ch),
        .dac(adc_dac),
        .cmp(adc_cmp)
    );

    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    task check_mem;
        input [7:0] addr;
        input [7:0] exp;
        input [255:0] label;
        reg   [7:0] got;
        begin
            got = dut.u_dmem.ram[addr];
            if (got === exp) begin
                $display("PASS: MEM[%0h] = %0h  (%0s)", addr, got, label);
                pass_count = pass_count + 1;
            end else begin
                $display("FAIL: MEM[%0h] = %0h (expected %0h)  (%0s)", addr, got, exp, label);
                fail_count = fail_count + 1;
            end
        end
    endtask

    initial begin
        rst = 1;
        #22 rst = 0;
        wait (halted);
        @(posedge clk); @(posedge clk);

        $display("\n--- SYSTEM INTEGRATION TEST RESULTS ---");
        check_mem(8'h80, 8'hA8, "Part A: ID register");
        check_mem(8'h81, 8'h81, "Part B: ADC_RCH valid, ch1");
        check_mem(8'h82, 8'h56, "Part B: ch1 code 1.111V");

        if (fail_count == 0)
            $display("\n*** SOC TEST PASSED (%0d checks) ***", pass_count);
        else
            $display("\n*** SOC TEST FAILED: %0d check(s) failed ***", fail_count);

        $finish;
    end

    initial begin
        #500000 $display("TIMEOUT"); $finish;
    end
endmodule
