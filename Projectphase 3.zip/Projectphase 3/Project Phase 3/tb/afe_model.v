`timescale 1ns/1ps

module afe_model (
    input  wire       sample,
    input  wire [1:0] ch,
    input  wire [7:0] dac,
    output reg        cmp
);
    reg [7:0] vin_arr [0:3];
    reg [7:0] v_held;

    initial begin
        vin_arr[0] = 8'd31;   // 0.40V  -> 0x1F
        vin_arr[1] = 8'd86;   // 1.111V -> 0x56
        vin_arr[2] = 8'd155;  // 2.00V  -> 0x9B
        vin_arr[3] = 8'd232;  // 3.00V  -> 0xE8
        v_held     = 8'd0;
        cmp        = 1'b0;
    end

    always @(*) begin
        if (sample)
            v_held = vin_arr[ch];
    end

    always @(*) begin
        cmp = (v_held >= dac);
    end
endmodule
