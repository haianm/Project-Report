`timescale 1ns/1ps

module timer_adc_sva (
    input logic       clk,
    input logic       rst,
    input logic       psel,
    input logic       penable,
    input logic       pwrite,
    input logic [3:0] paddr,
    input logic [7:0] prdata,
    input logic       adc_sample
);
    // 1. Hardware ID Register (0xF) must always return 0xA8 on APB read
    property p_periph_id_check;
        @(posedge clk) disable iff (rst)
        (psel && penable && !pwrite && (paddr == 4'hF)) |-> (prdata == 8'hA8);
    endproperty
    assert_periph_id: assert property (p_periph_id_check)
        else $error("[SVA FAIL] PERIPH_ID did not return 0xA8!");

    // 2. APB signals must never be X/Z when psel is asserted
    property p_no_x_on_sel;
        @(posedge clk) disable iff (rst)
        psel |-> (!$isunknown(pwrite) && !$isunknown(paddr));
    endproperty
    assert_no_x_bus: assert property (p_no_x_on_sel)
        else $error("[SVA FAIL] Unknown X/Z detected on APB bus during psel!");
endmodule
