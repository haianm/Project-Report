`timescale 1ns/1ps

interface timer_adc_if (input logic clk, input logic rst);
    logic       psel;
    logic       penable;
    logic       pwrite;
    logic [3:0] paddr;
    logic [7:0] pwdata;
    logic [7:0] prdata;

    logic       irq;
    logic       pwm_out;
    logic       adc_sample;
    logic [1:0] adc_ch;
    logic [7:0] adc_dac;
    logic       adc_cmp;

    clocking drv_cb @(posedge clk);
        default input #1step output #1ns;
        output psel, penable, pwrite, paddr, pwdata;
        input  prdata, irq, pwm_out, adc_sample, adc_ch, adc_dac;
    endclocking

    clocking mon_cb @(posedge clk);
        default input #1step;
        input psel, penable, pwrite, paddr, pwdata, prdata;
        input irq, pwm_out, adc_sample, adc_ch, adc_dac, adc_cmp;
    endclocking
endinterface
