`timescale 1ns/1ps
`include "uvm_mini_lib.sv"

package timer_adc_pkg;
    import uvm_pkg::*;

    class bus_txn extends uvm_sequence_item;
        rand bit       we;
        rand bit [3:0] addr;
        rand bit [7:0] wdata;
             bit [7:0] rdata;
             bit       irq_seen;

        constraint c_valid_addr { addr inside {[4'h0:4'hF]}; }

        function new(string name = "bus_txn");
            super.new(name);
        endfunction
    endclass

    class bus_driver extends uvm_driver #(bus_txn);
        virtual timer_adc_if vif;

        function new(string name, uvm_component parent);
            super.new(name, parent);
        endfunction

        virtual task run_phase(uvm_phase phase);
            vif.drv_cb.psel    <= 1'b0;
            vif.drv_cb.penable <= 1'b0;
            vif.drv_cb.pwrite  <= 1'b0;
            vif.drv_cb.paddr   <= 4'h0;
            vif.drv_cb.pwdata  <= 8'h00;
            @(negedge vif.rst);

            forever begin
                seq_item_port.get_next_item(req);
                // APB Setup Phase
                @(vif.drv_cb);
                vif.drv_cb.psel    <= 1'b1;
                vif.drv_cb.penable <= 1'b0;
                vif.drv_cb.pwrite  <= req.we;
                vif.drv_cb.paddr   <= req.addr;
                vif.drv_cb.pwdata  <= req.wdata;

                // APB Access Phase
                @(vif.drv_cb);
                vif.drv_cb.penable <= 1'b1;

                // Sample Read Data at end of Access Phase
                @(vif.drv_cb);
                if (!req.we)
                    req.rdata = vif.drv_cb.prdata;
                vif.drv_cb.psel    <= 1'b0;
                vif.drv_cb.penable <= 1'b0;
                vif.drv_cb.pwrite  <= 1'b0;
                seq_item_port.item_done();
            end
        endtask
    endclass

    class timer_adc_scoreboard extends uvm_scoreboard;
        bit [7:0] ref_regs [0:15];
        int       pass_cnt;
        int       fail_cnt;

        bit [7:0] exp_adc_code [0:3];
        bit [1:0] last_ch;

        function new(string name, uvm_component parent);
            super.new(name, parent);
            pass_cnt = 0;
            fail_cnt = 0;
            last_ch  = 2'd0;
            exp_adc_code[0] = 8'h1F;
            exp_adc_code[1] = 8'h56;
            exp_adc_code[2] = 8'h9B;
            exp_adc_code[3] = 8'hE8;

            foreach (ref_regs[i]) ref_regs[i] = 8'h00;
            ref_regs[4'h2] = 8'hFF;
            ref_regs[4'h3] = 8'h80;
            ref_regs[4'h6] = 8'h03;
            ref_regs[4'h9] = 8'hFF;
            ref_regs[4'hF] = 8'hA8;
        endfunction

        virtual function void write(bus_txn tr);
            if (tr.we) begin
                if (tr.addr inside {4'h0, 4'h1, 4'h2, 4'h3, 4'h6, 4'h7, 4'h8, 4'h9, 4'hD})
                    ref_regs[tr.addr] = tr.wdata;
                if (tr.addr == 4'h5)
                    last_ch = tr.wdata[5:4];
            end else begin
                case (tr.addr)
                    4'hF: begin
                        if (tr.rdata === 8'hA8) begin
                            pass_cnt++;
                            `uvm_info("SCB_PASS", $sformatf("PERIPH_ID read = 0x%02h (Expected 0xA8)", tr.rdata), UVM_LOW)
                        end else begin
                            fail_cnt++;
                            `uvm_error("SCB_FAIL", $sformatf("PERIPH_ID mismatch: got 0x%02h, exp 0xA8", tr.rdata))
                        end
                    end
                    4'hA: begin
                        if (tr.rdata === exp_adc_code[last_ch]) begin
                            pass_cnt++;
                            `uvm_info("SCB_PASS", $sformatf("ADC_DATA [CH%0d] = 0x%02h matched AFE model!", last_ch, tr.rdata), UVM_LOW)
                        end else begin
                            fail_cnt++;
                            `uvm_error("SCB_FAIL", $sformatf("ADC_DATA [CH%0d] mismatch: got 0x%02h, exp 0x%02h", last_ch, tr.rdata, exp_adc_code[last_ch]))
                        end
                    end
                    4'h0, 4'h1, 4'h2, 4'h3, 4'h6, 4'h7: begin
                        if (tr.rdata === ref_regs[tr.addr]) begin
                            pass_cnt++;
                            `uvm_info("SCB_PASS", $sformatf("REG[0x%0h] readback = 0x%02h matched!", tr.addr, tr.rdata), UVM_MEDIUM)
                        end else begin
                            fail_cnt++;
                            `uvm_error("SCB_FAIL", $sformatf("REG[0x%0h] mismatch: got 0x%02h, exp 0x%02h", tr.addr, tr.rdata, ref_regs[tr.addr]))
                        end
                    end
                    default: ;
                endcase
            end
        endfunction

        virtual function void report_phase(uvm_phase phase);
            `uvm_info("UVM_SUMMARY", $sformatf("\n========================================\n UVM SCOREBOARD: %0d PASSED, %0d FAILED\n========================================", pass_cnt, fail_cnt), UVM_NONE)
        endfunction
    endclass

    class bus_monitor extends uvm_monitor;
        virtual timer_adc_if vif;
        timer_adc_scoreboard scb_h;

        covergroup cg_periph;
            cp_addr: coverpoint tr.addr {
                bins tmr_regs[] = {[4'h0:4'h4]};
                bins adc_ctrl   = {4'h5};
                bins adc_cfg[]  = {[4'h6:4'h9]};
                bins adc_data   = {4'hA};
                bins adc_stat[] = {4'hB, 4'hC};
                bins irq_regs[] = {4'hD, 4'hE};
                bins id_reg     = {4'hF};
            }
            cp_rw: coverpoint tr.we {
                bins read  = {0};
                bins write = {1};
            }
            cx_addr_rw: cross cp_addr, cp_rw;
        endgroup

        bus_txn tr;

        function new(string name, uvm_component parent);
            super.new(name, parent);
            cg_periph = new();
        endfunction

        virtual task run_phase(uvm_phase phase);
            @(negedge vif.rst);
            forever begin
                @(vif.mon_cb);
                if (vif.mon_cb.psel && vif.mon_cb.penable) begin
                    tr          = new("tr");
                    tr.we       = vif.mon_cb.pwrite;
                    tr.addr     = vif.mon_cb.paddr;
                    tr.wdata    = vif.mon_cb.pwdata;
                    tr.rdata    = vif.mon_cb.prdata;
                    tr.irq_seen = vif.mon_cb.irq;
                    cg_periph.sample();
                    if (scb_h != null) scb_h.write(tr);
                end
            end
        endtask
    endclass

    class bus_agent extends uvm_agent;
        bus_driver               drv;
        bus_monitor              mon;
        uvm_sequencer #(bus_txn) sqr;

        function new(string name, uvm_component parent);
            super.new(name, parent);
        endfunction

        virtual function void build_phase(uvm_phase phase);
            super.build_phase(phase);
            mon = new("mon", this);
            drv = new("drv", this);
            sqr = new("sqr", this);
        endfunction

        virtual function void connect_phase(uvm_phase phase);
            super.connect_phase(phase);
            drv.seq_item_port = sqr;
        endfunction
    endclass

    class timer_adc_env extends uvm_env;
        bus_agent            agent;
        timer_adc_scoreboard scb;

        function new(string name, uvm_component parent);
            super.new(name, parent);
        endfunction

        virtual function void build_phase(uvm_phase phase);
            super.build_phase(phase);
            agent = new("agent", this);
            scb   = new("scb", this);
        endfunction

        virtual function void connect_phase(uvm_phase phase);
            super.connect_phase(phase);
            agent.mon.scb_h = scb;
        endfunction
    endclass

    class timer_adc_full_seq extends uvm_sequence #(bus_txn);
        function new(string name = "timer_adc_full_seq");
            super.new(name);
        endfunction

        task write_reg(bit [3:0] addr, bit [7:0] data);
            bus_txn tr;
            tr = new("tr");
            start_item(tr);
            tr.we = 1; tr.addr = addr; tr.wdata = data;
            finish_item(tr);
        endtask

        task read_reg(bit [3:0] addr, output bit [7:0] data);
            bus_txn tr;
            tr = new("tr");
            start_item(tr);
            tr.we = 0; tr.addr = addr; tr.wdata = 0;
            finish_item(tr);
            data = tr.rdata;
        endtask

        virtual task body();
            bit [7:0] rdata;
            `uvm_info("SEQ", "Step 1: Reading PERIPH_ID (0xF)...", UVM_LOW)
            read_reg(4'hF, rdata);

            `uvm_info("SEQ", "Step 2: Configuring Timer PWM (PRESC=1, LOAD=15, CMP=8)...", UVM_LOW)
            write_reg(4'h1, 8'd1);
            write_reg(4'h2, 8'd15);
            write_reg(4'h3, 8'd8);
            read_reg(4'h1, rdata);
            read_reg(4'h2, rdata);
            read_reg(4'h3, rdata);
            write_reg(4'h0, 8'h01);

            `uvm_info("SEQ", "Step 3: Converting SAR ADC Channels 0..3...", UVM_LOW)
            write_reg(4'h6, 8'd2);
            write_reg(4'h7, 8'd0);

            for (int ch = 0; ch < 4; ch++) begin
                write_reg(4'h5, {2'b00, ch[1:0], 2'b00, 2'b11});
                do begin
                    read_reg(4'hC, rdata);
                end while (rdata[4] == 1'b1);
                read_reg(4'hB, rdata);
                read_reg(4'hA, rdata);
            end
        endtask
    endclass

    class timer_adc_base_test extends uvm_test;
        timer_adc_env env;

        function new(string name, uvm_component parent);
            super.new(name, parent);
        endfunction

        virtual function void build_phase(uvm_phase phase);
            super.build_phase(phase);
            env = new("env", this);
        endfunction

        virtual task run_phase(uvm_phase phase);
            timer_adc_full_seq seq;
            phase.raise_objection(this);
            seq = new("seq");
            seq.start(env.agent.sqr);
            #100;
            phase.drop_objection(this);
        endtask
    endclass
endpackage
