`timescale 1ns/1ps

interface timer_adc_if (input logic clk, input logic rst);
    logic       psel;
    logic       penable;
    logic       pwrite;
    logic [3:0] paddr;
    logic [7:0] pwdata;
    logic [7:0] prdata;

    logic       irq;
    logic       pwm_out;
    logic       adc_sample;
    logic [1:0] adc_ch;
    logic [7:0] adc_dac;
    logic       adc_cmp;
endinterface

module timer_adc_sva (
    input logic       clk,
    input logic       rst,
    input logic       psel,
    input logic       penable,
    input logic       pwrite,
    input logic [3:0] paddr,
    input logic [7:0] prdata
);
    property p_periph_id_check;
        @(posedge clk) disable iff (rst)
        (psel && penable && !pwrite && (paddr == 4'hF)) |-> (prdata == 8'hA8);
    endproperty
    assert_periph_id: assert property (p_periph_id_check)
        else $error("[SVA FAIL] PERIPH_ID did not return 0xA8!");

    property p_no_x_on_sel;
        @(posedge clk) disable iff (rst)
        psel |-> (!$isunknown(pwrite) && !$isunknown(paddr));
    endproperty
    assert_no_x_bus: assert property (p_no_x_on_sel)
        else $error("[SVA FAIL] Unknown X/Z detected on APB bus during psel!");
endmodule

module tb_timer_adc_uvm;
    logic clk;
    logic rst;

    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        rst = 1;
        #25 rst = 0;
    end

    timer_adc_if vif (.clk(clk), .rst(rst));

    timer_adc8_top dut (
        .clk        (clk),
        .rst        (rst),
        .psel       (vif.psel),
        .penable    (vif.penable),
        .pwrite     (vif.pwrite),
        .paddr      (vif.paddr),
        .pwdata     (vif.pwdata),
        .prdata     (vif.prdata),
        .irq        (vif.irq),
        .pwm_out    (vif.pwm_out),
        .adc_sample (vif.adc_sample),
        .adc_ch     (vif.adc_ch),
        .adc_dac    (vif.adc_dac),
        .adc_cmp    (vif.adc_cmp)
    );

    afe_model u_afe (
        .sample (vif.adc_sample),
        .ch     (vif.adc_ch),
        .dac    (vif.adc_dac),
        .cmp    (vif.adc_cmp)
    );

    timer_adc_sva u_sva (
        .clk     (clk),
        .rst     (rst),
        .psel    (vif.psel),
        .penable (vif.penable),
        .pwrite  (vif.pwrite),
        .paddr   (vif.paddr),
        .prdata  (vif.prdata)
    );

    // UVM Scoreboard & Coverage State
    bit [7:0]  ref_regs [0:15];
    bit [7:0]  exp_adc_code [0:3];
    bit [1:0]  last_ch;
    int        pass_cnt;
    int        fail_cnt;
    bit [15:0] addr_cov_mask;

    function automatic void scb_init();
        pass_cnt      = 0;
        fail_cnt      = 0;
        last_ch       = 2'd0;
        addr_cov_mask = 16'h0000;
        exp_adc_code[0] = 8'h1F;
        exp_adc_code[1] = 8'h56;
        exp_adc_code[2] = 8'h9B;
        exp_adc_code[3] = 8'hE8;
        for (int i = 0; i < 16; i++) ref_regs[i] = 8'h00;
        ref_regs[4'h2] = 8'hFF;
        ref_regs[4'h3] = 8'h80;
        ref_regs[4'h6] = 8'h03;
        ref_regs[4'h9] = 8'hFF;
        ref_regs[4'hF] = 8'hA8;
    endfunction

    function automatic void scb_check(input bit we, input bit [3:0] addr, input bit [7:0] wdata, input bit [7:0] rdata);
        addr_cov_mask[addr] = 1'b1;
        if (we) begin
            if (addr inside {4'h0, 4'h1, 4'h2, 4'h3, 4'h6, 4'h7, 4'h8, 4'h9, 4'hD})
                ref_regs[addr] = wdata;
            if (addr == 4'h5)
                last_ch = wdata[5:4];
        end else begin
            case (addr)
                4'hF: begin
                    if (rdata === 8'hA8) begin
                        pass_cnt++;
                        $display("[%0t ns] UVM_INFO (SCB_PASS): PERIPH_ID = 0x%02h (Expected 0xA8)", $time, rdata);
                    end else begin
                        fail_cnt++;
                        $display("[%0t ns] UVM_ERROR (SCB_FAIL): PERIPH_ID got 0x%02h, exp 0xA8", $time, rdata);
                    end
                end
                4'hA: begin
                    if (rdata === exp_adc_code[last_ch]) begin
                        pass_cnt++;
                        $display("[%0t ns] UVM_INFO (SCB_PASS): ADC_DATA [CH%0d] = 0x%02h matched AFE model!", $time, last_ch, rdata);
                    end else begin
                        fail_cnt++;
                        $display("[%0t ns] UVM_ERROR (SCB_FAIL): ADC_DATA [CH%0d] got 0x%02h, exp 0x%02h", $time, last_ch, rdata, exp_adc_code[last_ch]);
                    end
                end
                4'h0, 4'h1, 4'h2, 4'h3, 4'h6, 4'h7: begin
                    if (rdata === ref_regs[addr]) begin
                        pass_cnt++;
                        $display("[%0t ns] UVM_INFO (SCB_PASS): REG[0x%0h] readback = 0x%02h matched!", $time, addr, rdata);
                    end else begin
                        fail_cnt++;
                        $display("[%0t ns] UVM_ERROR (SCB_FAIL): REG[0x%0h] got 0x%02h, exp 0x%02h", $time, addr, rdata, ref_regs[addr]);
                    end
                end
                default: ;
            endcase
        end
    endfunction

    task automatic apb_write(input bit [3:0] addr, input bit [7:0] data);
        @(posedge clk);
        vif.psel    <= 1'b1;
        vif.penable <= 1'b0;
        vif.pwrite  <= 1'b1;
        vif.paddr   <= addr;
        vif.pwdata  <= data;

        @(posedge clk);
        vif.penable <= 1'b1;

        @(posedge clk);
        scb_check(1'b1, addr, data, 8'h00);
        vif.psel    <= 1'b0;
        vif.penable <= 1'b0;
        vif.pwrite  <= 1'b0;
    endtask

    task automatic apb_read(input bit [3:0] addr, output bit [7:0] data);
        @(posedge clk);
        vif.psel    <= 1'b1;
        vif.penable <= 1'b0;
        vif.pwrite  <= 1'b0;
        vif.paddr   <= addr;
        vif.pwdata  <= 8'h00;

        @(posedge clk);
        vif.penable <= 1'b1;

        @(posedge clk);
        data = vif.prdata;
        scb_check(1'b0, addr, 8'h00, data);
        vif.psel    <= 1'b0;
        vif.penable <= 1'b0;
    endtask

    initial begin
        bit [7:0] rdata;
        int hit_bins;
        real cov_pct;

        vif.psel    = 1'b0;
        vif.penable = 1'b0;
        vif.pwrite  = 1'b0;
        vif.paddr   = 4'h0;
        vif.pwdata  = 8'h00;

        scb_init();
        @(negedge rst);
        @(posedge clk);

        $display("[%0t ns] UVM_INFO (SEQ): Step 1 - Verifying PERIPH_ID (0xF)...", $time);
        apb_read(4'hF, rdata);

        $display("[%0t ns] UVM_INFO (SEQ): Step 2 - Configuring Timer PWM & Verifying Readback...", $time);
        apb_write(4'h1, 8'd1);
        apb_write(4'h2, 8'd15);
        apb_write(4'h3, 8'd8);
        apb_read(4'h1, rdata);
        apb_read(4'h2, rdata);
        apb_read(4'h3, rdata);
        apb_write(4'h0, 8'h01);

        $display("[%0t ns] UVM_INFO (SEQ): Step 3 - Running 4-Channel SAR ADC Conversions...", $time);
        apb_write(4'h6, 8'd2);
        apb_write(4'h7, 8'd0);

        for (int ch = 0; ch < 4; ch++) begin
            apb_write(4'h5, {2'b00, ch[1:0], 2'b00, 2'b11});
            do begin
                apb_read(4'hC, rdata);
            end while (rdata[4] == 1'b1);

            apb_read(4'hB, rdata);
            apb_read(4'hA, rdata);
        end

        #100;
        hit_bins = 0;
        for (int i = 0; i < 16; i++) if (addr_cov_mask[i]) hit_bins++;
        cov_pct = (hit_bins * 100.0) / 16.0;

        $display("\n========================================");
        $display(" UVM SCOREBOARD: %0d PASSED, %0d FAILED", pass_cnt, fail_cnt);
        $display(" Register Functional Coverage: %0.2f %% (%0d/16 regs)", cov_pct, hit_bins);
        $display("========================================\n");
        $finish;
    end

    initial begin
        #50000;
        $display("[TIMEOUT] Simulation exceeded 50us!");
        $finish;
    end
endmodule