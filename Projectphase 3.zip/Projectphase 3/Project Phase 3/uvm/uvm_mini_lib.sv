`timescale 1ns/1ps

`ifndef UVM_MINI_LIB_SV
`define UVM_MINI_LIB_SV

`define uvm_info(ID, MSG, VERB)     $display("[%0t ns] UVM_INFO (%s): %s", $time, ID, MSG);

`define uvm_error(ID, MSG)     $display("[%0t ns] UVM_ERROR (%s): %s", $time, ID, MSG);

`define uvm_fatal(ID, MSG)     begin $display("[%0t ns] UVM_FATAL (%s): %s", $time, ID, MSG); $finish; end

package uvm_pkg;
    typedef enum int { UVM_NONE=0, UVM_LOW=100, UVM_MEDIUM=200, UVM_HIGH=300 } uvm_verbosity;

    class uvm_void;
    endclass

    class uvm_object extends uvm_void;
        string name;
        function new(string name="");
            this.name = name;
        endfunction
        function string get_name();
            return name;
        endfunction
    endclass

    class uvm_phase extends uvm_object;
        int objection_count;
        function new(string name="run_phase");
            super.new(name);
            objection_count = 0;
        endfunction
        function void raise_objection(uvm_object obj=null);
            objection_count++;
        endfunction
        function void drop_objection(uvm_object obj=null);
            if (objection_count > 0) objection_count--;
        endfunction
    endclass

    class uvm_component extends uvm_object;
        uvm_component parent;
        function new(string name="", uvm_component parent=null);
            super.new(name);
            this.parent = parent;
        endfunction
        virtual function void build_phase(uvm_phase phase); endfunction
        virtual function void connect_phase(uvm_phase phase); endfunction
        virtual task run_phase(uvm_phase phase); endtask
        virtual function void report_phase(uvm_phase phase); endfunction
    endclass

    class uvm_sequence_item extends uvm_object;
        function new(string name="uvm_sequence_item");
            super.new(name);
        endfunction
    endclass

    class uvm_sequencer #(type REQ=uvm_sequence_item) extends uvm_component;
        mailbox #(REQ) req_mb;
        event          item_done_ev;
        function new(string name="", uvm_component parent=null);
            super.new(name, parent);
            req_mb = new();
        endfunction
        task get_next_item(output REQ req);
            req_mb.get(req);
        endtask
        function void item_done();
            -> item_done_ev;
        endfunction
    endclass

    class uvm_driver #(type REQ=uvm_sequence_item) extends uvm_component;
        uvm_sequencer #(REQ) seq_item_port;
        REQ req;
        function new(string name="", uvm_component parent=null);
            super.new(name, parent);
        endfunction
    endclass

    class uvm_monitor extends uvm_component;
        function new(string name="", uvm_component parent=null);
            super.new(name, parent);
        endfunction
    endclass

    class uvm_agent extends uvm_component;
        function new(string name="", uvm_component parent=null);
            super.new(name, parent);
        endfunction
    endclass

    class uvm_scoreboard extends uvm_component;
        function new(string name="", uvm_component parent=null);
            super.new(name, parent);
        endfunction
    endclass

    class uvm_env extends uvm_component;
        function new(string name="", uvm_component parent=null);
            super.new(name, parent);
        endfunction
    endclass

    class uvm_test extends uvm_component;
        function new(string name="", uvm_component parent=null);
            super.new(name, parent);
        endfunction
    endclass

    class uvm_sequence #(type REQ=uvm_sequence_item) extends uvm_object;
        uvm_sequencer #(REQ) m_sequencer;
        function new(string name="uvm_sequence");
            super.new(name);
        endfunction
        task start(uvm_sequencer #(REQ) sqr);
            m_sequencer = sqr;
            body();
        endtask
        virtual task body(); endtask
        task start_item(REQ item); endtask
        task finish_item(REQ item);
            m_sequencer.req_mb.put(item);
            @(m_sequencer.item_done_ev);
        endtask
    endclass
endpackage

`endif
