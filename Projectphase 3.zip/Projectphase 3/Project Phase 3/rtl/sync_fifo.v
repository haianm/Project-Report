`timescale 1ns/1ps

module sync_fifo #(
    parameter WIDTH = 10,
    parameter DEPTH = 8
)(
    input  wire             clk,
    input  wire             rst,
    input  wire             push,
    input  wire [WIDTH-1:0] din,
    input  wire             pop,
    output wire [WIDTH-1:0] dout,
    output wire             full,
    output wire             empty,
    output reg  [3:0]       level
);
    reg [WIDTH-1:0] mem [0:DEPTH-1];
    reg [2:0] wr_ptr;
    reg [2:0] rd_ptr;

    assign full  = (level == DEPTH[3:0]);
    assign empty = (level == 4'd0);
    assign dout  = mem[rd_ptr];

    wire do_push = push && !full;
    wire do_pop  = pop  && !empty;

    always @(posedge clk or posedge rst) begin
        if (rst) begin
            wr_ptr <= 3'd0;
            rd_ptr <= 3'd0;
            level  <= 4'd0;
        end else begin
            if (do_push) begin
                mem[wr_ptr] <= din;
                wr_ptr      <= wr_ptr + 3'd1;
            end
            if (do_pop) begin
                rd_ptr <= rd_ptr + 3'd1;
            end

            case ({do_push, do_pop})
                2'b10: level <= level + 4'd1;
                2'b01: level <= level - 4'd1;
                default: level <= level;
            endcase
        end
    end
endmodule
