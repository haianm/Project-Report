`timescale 1ns/1ps

module alu (
    input  wire [3:0] op,
    input  wire [7:0] a,
    input  wire [7:0] b,
    input  wire [2:0] shamt,
    output reg  [7:0] y
);
    always @(*) begin
        case (op)
            4'h1: y = a + b;          // ADD
            4'h2: y = a - b;          // SUB
            4'h3: y = a & b;          // AND
            4'h4: y = a | b;          // OR
            4'h5: y = a ^ b;          // XOR
            4'h6: y = a << shamt;     // SHL
            4'h7: y = a >> shamt;     // SHR
            4'h8: y = b;              // LDI (pass imm)
            4'h9: y = a + b;          // ADDI
            4'hA: y = a;              // LD (addr = rs1)
            4'hB: y = a;              // ST (addr = rs1)
            default: y = 8'h00;
        endcase
    end
endmodule
