`timescale 1ns/1ps

module apb_regs8 (
    input  wire       clk,
    input  wire       rst,
    input  wire       psel,
    input  wire       penable,
    input  wire       pwrite,
    input  wire [3:0] paddr,
    input  wire [7:0] pwdata,
    output reg  [7:0] prdata,

    // Timer
    output wire       tmr_en,
    output wire       tmr_oneshot,
    output wire [7:0] tmr_presc,
    output wire [7:0] tmr_load,
    output wire [7:0] tmr_cmp,
    input  wire [7:0] tmr_cnt,
    input  wire       tmr_ovf,
    input  wire       tmr_cmp_pulse,

    // ADC
    output wire       adc_en,
    output wire       adc_sw_start,
    output wire [1:0] adc_trig_sel,
    output wire [1:0] adc_ch,
    output wire [7:0] adc_smp,
    output wire [7:0] adc_div,
    output wire [7:0] adc_thr_lo,
    output wire [7:0] adc_thr_hi,
    input  wire       adc_busy,
    input  wire       adc_eoc,
    input  wire       adc_wd_match,
    input  wire       adc_trig_miss,

    // FIFO
    output wire       fifo_pop,
    input  wire [9:0] fifo_dout,
    input  wire       fifo_full,
    input  wire       fifo_empty,
    input  wire [3:0] fifo_level,
    input  wire       fifo_ovr,

    output wire       irq
);
    reg [7:0] r_tmr_ctrl;
    reg [7:0] r_tmr_presc;
    reg [7:0] r_tmr_load;
    reg [7:0] r_tmr_cmp;
    reg [7:0] r_adc_ctrl;
    reg [7:0] r_adc_smp;
    reg [7:0] r_adc_div;
    reg [7:0] r_adc_thr_lo;
    reg [7:0] r_adc_thr_hi;
    reg [7:0] r_irq_en;
    reg [7:0] r_irq_stat;

    wire wr_en = psel && penable && pwrite;
    wire rd_en = psel && penable && !pwrite;

    assign tmr_en       = r_tmr_ctrl[0];
    assign tmr_oneshot  = r_tmr_ctrl[1];
    assign tmr_presc    = r_tmr_presc;
    assign tmr_load     = r_tmr_load;
    assign tmr_cmp      = r_tmr_cmp;

    // Immediate combinational bypass on control write so START captures EN & CH in same cycle
    assign adc_en       = r_adc_ctrl[0] | (wr_en && (paddr == 4'h5) && pwdata[0]);
    assign adc_sw_start = (wr_en && (paddr == 4'h5) && pwdata[1]);
    assign adc_trig_sel = (wr_en && (paddr == 4'h5)) ? pwdata[3:2] : r_adc_ctrl[3:2];
    assign adc_ch       = (wr_en && (paddr == 4'h5)) ? pwdata[5:4] : r_adc_ctrl[5:4];
    assign adc_smp      = r_adc_smp;
    assign adc_div      = r_adc_div;
    assign adc_thr_lo   = r_adc_thr_lo;
    assign adc_thr_hi   = r_adc_thr_hi;

    assign fifo_pop     = rd_en && (paddr == 4'hA);
    assign irq          = |(r_irq_stat & r_irq_en);

    always @(posedge clk or posedge rst) begin
        if (rst) begin
            r_tmr_ctrl   <= 8'h00;
            r_tmr_presc  <= 8'h00;
            r_tmr_load   <= 8'hFF;
            r_tmr_cmp    <= 8'h80;
            r_adc_ctrl   <= 8'h00;
            r_adc_smp    <= 8'h03;
            r_adc_div    <= 8'h00;
            r_adc_thr_lo <= 8'h00;
            r_adc_thr_hi <= 8'hFF;
            r_irq_en     <= 8'h00;
            r_irq_stat   <= 8'h00;
        end else begin
            r_adc_ctrl[1] <= 1'b0;

            if (wr_en) begin
                case (paddr)
                    4'h0: r_tmr_ctrl   <= pwdata;
                    4'h1: r_tmr_presc  <= pwdata;
                    4'h2: r_tmr_load   <= pwdata;
                    4'h3: r_tmr_cmp    <= pwdata;
                    4'h5: r_adc_ctrl   <= {pwdata[7:2], 1'b0, pwdata[0]};
                    4'h6: r_adc_smp    <= pwdata;
                    4'h7: r_adc_div    <= pwdata;
                    4'h8: r_adc_thr_lo <= pwdata;
                    4'h9: r_adc_thr_hi <= pwdata;
                    4'hD: r_irq_en     <= pwdata;
                    default: ;
                endcase
            end

            if (wr_en && (paddr == 4'hE))
                r_irq_stat <= (r_irq_stat & ~pwdata) | {2'b00, adc_trig_miss, fifo_ovr, adc_wd_match, adc_eoc, tmr_cmp_pulse, tmr_ovf};
            else
                r_irq_stat <= r_irq_stat | {2'b00, adc_trig_miss, fifo_ovr, adc_wd_match, adc_eoc, tmr_cmp_pulse, tmr_ovf};
        end
    end

    always @(*) begin
        case (paddr)
            4'h0: prdata = r_tmr_ctrl;
            4'h1: prdata = r_tmr_presc;
            4'h2: prdata = r_tmr_load;
            4'h3: prdata = r_tmr_cmp;
            4'h4: prdata = tmr_cnt;
            4'h5: prdata = r_adc_ctrl;
            4'h6: prdata = r_adc_smp;
            4'h7: prdata = r_adc_div;
            4'h8: prdata = r_adc_thr_lo;
            4'h9: prdata = r_adc_thr_hi;
            4'hA: prdata = fifo_dout[7:0];
            4'hB: prdata = {!fifo_empty, 5'b00000, fifo_dout[9:8]};
            4'hC: prdata = {1'b0, adc_busy, fifo_full, fifo_empty, fifo_level};
            4'hD: prdata = r_irq_en;
            4'hE: prdata = r_irq_stat;
            4'hF: prdata = 8'hA8; // PERIPH_ID
            default: prdata = 8'h00;
        endcase
    end
endmodule
