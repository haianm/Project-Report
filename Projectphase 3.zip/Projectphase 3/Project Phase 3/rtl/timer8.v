`timescale 1ns/1ps

module timer8 (
    input  wire       clk,
    input  wire       rst,
    input  wire       en,
    input  wire       oneshot,
    input  wire [7:0] presc,
    input  wire [7:0] load,
    input  wire [7:0] cmp,
    output reg  [7:0] cnt,
    output reg        ovf_pulse,
    output reg        cmp_pulse,
    output wire       pwm_out
);
    reg [7:0] p_cnt;
    reg       stopped;

    always @(posedge clk or posedge rst) begin
        if (rst) begin
            p_cnt     <= 8'd0;
            cnt       <= 8'd0;
            ovf_pulse <= 1'b0;
            cmp_pulse <= 1'b0;
            stopped   <= 1'b0;
        end else begin
            ovf_pulse <= 1'b0;
            cmp_pulse <= 1'b0;

            if (!en) begin
                p_cnt   <= 8'd0;
                cnt     <= 8'd0;
                stopped <= 1'b0;
            end else if (!stopped) begin
                if (p_cnt == presc) begin
                    p_cnt <= 8'd0;
                    if (cnt == cmp)
                        cmp_pulse <= 1'b1;

                    if (cnt == load) begin
                        cnt       <= 8'd0;
                        ovf_pulse <= 1'b1;
                        if (oneshot)
                            stopped <= 1'b1;
                    end else begin
                        cnt <= cnt + 8'd1;
                    end
                end else begin
                    p_cnt <= p_cnt + 8'd1;
                end
            end
        end
    end

    assign pwm_out = en && !stopped && (cnt < cmp);
endmodule
