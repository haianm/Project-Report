`timescale 1ns/1ps

module sar_adc_ctrl (
    input  wire       clk,
    input  wire       rst,
    input  wire       en,
    input  wire       start,
    input  wire [1:0] ch_in,
    input  wire [7:0] smp_cycles,
    input  wire [7:0] clk_div,
    input  wire       cmp_in,
    output reg        sample,
    output reg  [1:0] ch_out,
    output reg  [7:0] dac_val,
    output reg  [7:0] result,
    output reg  [1:0] res_ch,
    output reg        eoc,
    output wire       busy
);
    localparam S_IDLE    = 2'd0;
    localparam S_SAMPLE  = 2'd1;
    localparam S_CONVERT = 2'd2;
    localparam S_DONE    = 2'd3;

    reg [1:0] state;
    reg [7:0] div_cnt;
    reg [7:0] smp_cnt;
    reg [2:0] bit_idx;
    reg [7:0] approx;

    wire sar_tick = (div_cnt == clk_div);
    assign busy = (state != S_IDLE);

    always @(posedge clk or posedge rst) begin
        if (rst) begin
            state   <= S_IDLE;
            div_cnt <= 8'd0;
            smp_cnt <= 8'd0;
            bit_idx <= 3'd7;
            approx  <= 8'd0;
            sample  <= 1'b0;
            ch_out  <= 2'd0;
            dac_val <= 8'd0;
            result  <= 8'd0;
            res_ch  <= 2'd0;
            eoc     <= 1'b0;
        end else begin
            eoc <= 1'b0;

            if (!en) begin
                state   <= S_IDLE;
                sample  <= 1'b0;
                dac_val <= 8'd0;
                div_cnt <= 8'd0;
            end else begin
                case (state)
                    S_IDLE: begin
                        sample  <= 1'b0;
                        dac_val <= 8'd0;
                        div_cnt <= 8'd0;
                        if (start) begin
                            state   <= S_SAMPLE;
                            ch_out  <= ch_in;
                            smp_cnt <= 8'd0;
                            sample  <= 1'b1;
                        end
                    end

                    S_SAMPLE: begin
                        sample <= 1'b1;
                        if (smp_cnt >= smp_cycles) begin
                            sample  <= 1'b0;
                            state   <= S_CONVERT;
                            bit_idx <= 3'd7;
                            approx  <= 8'h80;
                            dac_val <= 8'h80;
                            div_cnt <= 8'd0;
                        end else begin
                            smp_cnt <= smp_cnt + 8'd1;
                        end
                    end

                    S_CONVERT: begin
                        if (sar_tick) begin
                            div_cnt <= 8'd0;
                            if (bit_idx == 3'd0) begin
                                result <= cmp_in ? (approx | 8'h01) : (approx & ~8'h01);
                                res_ch <= ch_out;
                                state  <= S_DONE;
                            end else begin
                                if (!cmp_in)
                                    approx[bit_idx] <= 1'b0;
                                approx[bit_idx - 3'd1] <= 1'b1;
                                dac_val <= (cmp_in ? approx : (approx & ~(8'h01 << bit_idx))) | (8'h01 << (bit_idx - 3'd1));
                                bit_idx <= bit_idx - 3'd1;
                            end
                        end else begin
                            div_cnt <= div_cnt + 8'd1;
                        end
                    end

                    S_DONE: begin
                        eoc     <= 1'b1;
                        dac_val <= 8'd0;
                        state   <= S_IDLE;
                    end
                endcase
            end
        end
    end
endmodule
