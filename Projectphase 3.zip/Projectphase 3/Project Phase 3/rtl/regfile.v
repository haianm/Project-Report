`timescale 1ns/1ps

module regfile (
    input  wire       clk,
    input  wire       rst,
    input  wire       we,
    input  wire [2:0] waddr,
    input  wire [7:0] wdata,
    input  wire [2:0] raddr1,
    input  wire [2:0] raddr2,
    output wire [7:0] rdata1,
    output wire [7:0] rdata2
);
    reg [7:0] regs [0:7];
    integer i;

    always @(posedge clk or posedge rst) begin
        if (rst) begin
            for (i = 0; i < 8; i = i + 1)
                regs[i] <= 8'h00;
        end else if (we) begin
            regs[waddr] <= wdata;
        end
    end

    assign rdata1 = (we && (waddr == raddr1)) ? wdata : regs[raddr1];
    assign rdata2 = (we && (waddr == raddr2)) ? wdata : regs[raddr2];
endmodule
