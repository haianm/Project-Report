`timescale 1ns/1ps

module timer_adc8_cpu_if (
    input  wire       io_cs,
    input  wire       io_we,
    input  wire [3:0] io_addr,
    input  wire [7:0] io_wdata,
    output wire [7:0] io_rdata,

    output wire       psel,
    output wire       penable,
    output wire       pwrite,
    output wire [3:0] paddr,
    output wire [7:0] pwdata,
    input  wire [7:0] prdata
);
    assign psel     = io_cs;
    assign penable  = io_cs;
    assign pwrite   = io_we;
    assign paddr    = io_addr;
    assign pwdata   = io_wdata;
    assign io_rdata = prdata;
endmodule
