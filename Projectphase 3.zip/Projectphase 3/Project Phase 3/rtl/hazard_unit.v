`timescale 1ns/1ps

module hazard_unit (
    input  wire [2:0] idex_rs1,
    input  wire [2:0] idex_rs2,
    input  wire       exmem_reg_we,
    input  wire [2:0] exmem_rd,
    input  wire       memwb_reg_we,
    input  wire [2:0] memwb_rd,
    output wire [1:0] fwd_a,
    output wire [1:0] fwd_b
);
    assign fwd_a = (exmem_reg_we && (exmem_rd == idex_rs1)) ? 2'b10 :
                   (memwb_reg_we && (memwb_rd == idex_rs1)) ? 2'b01 : 2'b00;

    assign fwd_b = (exmem_reg_we && (exmem_rd == idex_rs2)) ? 2'b10 :
                   (memwb_reg_we && (memwb_rd == idex_rs2)) ? 2'b01 : 2'b00;
endmodule
