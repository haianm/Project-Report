`timescale 1ns/1ps

module risc8_soc (
    input  wire       clk,
    input  wire       rst,
    output wire       halted,
    output wire [7:0] pc_out,
    output wire       irq,
    output wire       pwm_out,
    output wire       adc_sample,
    output wire [1:0] adc_ch,
    output wire [7:0] adc_dac,
    input  wire       adc_cmp
);
    wire [7:0]  imem_addr;
    wire [15:0] imem_rdata;
    wire        dmem_we;
    wire [7:0]  dmem_addr, dmem_wdata, dmem_rdata;

    wire        io_cs, io_we;
    wire [3:0]  io_addr;
    wire [7:0]  io_wdata, io_rdata;

    wire        psel, penable, pwrite;
    wire [3:0]  paddr;
    wire [7:0]  pwdata, prdata;

    assign pc_out = imem_addr;

    imem u_imem (
        .addr(imem_addr),
        .rdata(imem_rdata)
    );

    dmem u_dmem (
        .clk(clk),
        .we(dmem_we),
        .addr(dmem_addr),
        .wdata(dmem_wdata),
        .rdata(dmem_rdata)
    );

    risc8_5stage_core u_cpu (
        .clk(clk),
        .rst(rst),
        .imem_addr(imem_addr),
        .imem_rdata(imem_rdata),
        .dmem_we(dmem_we),
        .dmem_addr(dmem_addr),
        .dmem_wdata(dmem_wdata),
        .dmem_rdata(dmem_rdata),
        .io_cs(io_cs),
        .io_we(io_we),
        .io_addr(io_addr),
        .io_wdata(io_wdata),
        .io_rdata(io_rdata),
        .halted(halted)
    );

    timer_adc8_cpu_if u_cpu_if (
        .io_cs(io_cs),
        .io_we(io_we),
        .io_addr(io_addr),
        .io_wdata(io_wdata),
        .io_rdata(io_rdata),
        .psel(psel),
        .penable(penable),
        .pwrite(pwrite),
        .paddr(paddr),
        .pwdata(pwdata),
        .prdata(prdata)
    );

    timer_adc8_top u_tadc (
        .clk(clk),
        .rst(rst),
        .psel(psel),
        .penable(penable),
        .pwrite(pwrite),
        .paddr(paddr),
        .pwdata(pwdata),
        .prdata(prdata),
        .irq(irq),
        .pwm_out(pwm_out),
        .adc_sample(adc_sample),
        .adc_ch(adc_ch),
        .adc_dac(adc_dac),
        .adc_cmp(adc_cmp)
    );
endmodule
