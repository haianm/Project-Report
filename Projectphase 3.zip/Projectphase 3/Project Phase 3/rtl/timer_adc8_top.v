`timescale 1ns/1ps

module timer_adc8_top (
    input  wire       clk,
    input  wire       rst,
    // APB Bus Interface
    input  wire       psel,
    input  wire       penable,
    input  wire       pwrite,
    input  wire [3:0] paddr,
    input  wire [7:0] pwdata,
    output wire [7:0] prdata,
    // External & Interrupt Pins
    output wire       irq,
    output wire       pwm_out,
    output wire       adc_sample,
    output wire [1:0] adc_ch,
    output wire [7:0] adc_dac,
    input  wire       adc_cmp
);
    wire       tmr_en, tmr_oneshot, tmr_ovf, tmr_cmp_pulse;
    wire [7:0] tmr_presc, tmr_load, tmr_cmp, tmr_cnt;

    wire       adc_en, adc_sw_start, adc_busy, adc_eoc;
    wire [1:0] adc_trig_sel, adc_cfg_ch, adc_res_ch;
    wire [7:0] adc_smp, adc_div, adc_thr_lo, adc_thr_hi, adc_res;

    wire       fifo_pop, fifo_full, fifo_empty;
    wire [9:0] fifo_dout;
    wire [3:0] fifo_level;

    reg trig_src;
    always @(*) begin
        case (adc_trig_sel)
            2'd0: trig_src = adc_sw_start;
            2'd1: trig_src = tmr_ovf;
            2'd2: trig_src = tmr_cmp_pulse;
            2'd3: trig_src = adc_en && !adc_busy;
        endcase
    end

    wire adc_start_pulse = trig_src && !adc_busy;
    wire adc_trig_miss   = trig_src && adc_busy;
    wire adc_wd_match    = adc_eoc && ((adc_res < adc_thr_lo) || (adc_res > adc_thr_hi));
    wire fifo_ovr        = adc_eoc && fifo_full;

    apb_regs8 u_regs (
        .clk(clk), .rst(rst),
        .psel(psel), .penable(penable), .pwrite(pwrite),
        .paddr(paddr), .pwdata(pwdata), .prdata(prdata),
        .tmr_en(tmr_en), .tmr_oneshot(tmr_oneshot),
        .tmr_presc(tmr_presc), .tmr_load(tmr_load), .tmr_cmp(tmr_cmp),
        .tmr_cnt(tmr_cnt), .tmr_ovf(tmr_ovf), .tmr_cmp_pulse(tmr_cmp_pulse),
        .adc_en(adc_en), .adc_sw_start(adc_sw_start),
        .adc_trig_sel(adc_trig_sel), .adc_ch(adc_cfg_ch),
        .adc_smp(adc_smp), .adc_div(adc_div),
        .adc_thr_lo(adc_thr_lo), .adc_thr_hi(adc_thr_hi),
        .adc_busy(adc_busy), .adc_eoc(adc_eoc),
        .adc_wd_match(adc_wd_match), .adc_trig_miss(adc_trig_miss),
        .fifo_pop(fifo_pop), .fifo_dout(fifo_dout),
        .fifo_full(fifo_full), .fifo_empty(fifo_empty),
        .fifo_level(fifo_level), .fifo_ovr(fifo_ovr),
        .irq(irq)
    );

    timer8 u_tmr (
        .clk(clk), .rst(rst),
        .en(tmr_en), .oneshot(tmr_oneshot),
        .presc(tmr_presc), .load(tmr_load), .cmp(tmr_cmp),
        .cnt(tmr_cnt), .ovf_pulse(tmr_ovf), .cmp_pulse(tmr_cmp_pulse),
        .pwm_out(pwm_out)
    );

    sar_adc_ctrl u_adc (
        .clk(clk), .rst(rst),
        .en(adc_en), .start(adc_start_pulse), .ch_in(adc_cfg_ch),
        .smp_cycles(adc_smp), .clk_div(adc_div), .cmp_in(adc_cmp),
        .sample(adc_sample), .ch_out(adc_ch), .dac_val(adc_dac),
        .result(adc_res), .res_ch(adc_res_ch), .eoc(adc_eoc), .busy(adc_busy)
    );

    sync_fifo #(.WIDTH(10), .DEPTH(8)) u_fifo (
        .clk(clk), .rst(rst),
        .push(adc_eoc), .din({adc_res_ch, adc_res}),
        .pop(fifo_pop), .dout(fifo_dout),
        .full(fifo_full), .empty(fifo_empty), .level(fifo_level)
    );
endmodule
