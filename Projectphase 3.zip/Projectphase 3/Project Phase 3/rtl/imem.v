`timescale 1ns/1ps

module imem (
    input  wire [7:0]  addr,
    output wire [15:0] rdata
);
    reg [15:0] rom [0:255];
    integer i;

    initial begin
        for (i = 0; i < 256; i = i + 1)
            rom[i] = 16'h0000;
        $readmemh("soc_demo.hex", rom);
    end

    assign rdata = rom[addr];
endmodule
