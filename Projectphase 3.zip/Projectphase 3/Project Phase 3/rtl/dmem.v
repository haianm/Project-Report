`timescale 1ns/1ps

module dmem (
    input  wire       clk,
    input  wire       we,
    input  wire [7:0] addr,
    input  wire [7:0] wdata,
    output wire [7:0] rdata
);
    reg [7:0] ram [0:255];
    integer i;

    initial begin
        for (i = 0; i < 256; i = i + 1)
            ram[i] = 8'h00;
    end

    always @(posedge clk) begin
        if (we)
            ram[addr] <= wdata;
    end

    assign rdata = ram[addr];
endmodule
