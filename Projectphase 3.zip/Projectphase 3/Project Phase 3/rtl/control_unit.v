`timescale 1ns/1ps

module control_unit (
    input  wire [3:0] opcode,
    output reg        reg_we,
    output reg        mem_read,
    output reg        mem_write,
    output reg        use_imm,
    output reg        is_branch,
    output reg        is_halt
);
    always @(*) begin
        reg_we    = 1'b0;
        mem_read  = 1'b0;
        mem_write = 1'b0;
        use_imm   = 1'b0;
        is_branch = 1'b0;
        is_halt   = 1'b0;

        case (opcode)
            4'h1, 4'h2, 4'h3, 4'h4, 4'h5, 4'h6, 4'h7: begin
                reg_we = 1'b1;
            end
            4'h8, 4'h9: begin // LDI, ADDI
                reg_we  = 1'b1;
                use_imm = 1'b1;
            end
            4'hA: begin // LD
                reg_we   = 1'b1;
                mem_read = 1'b1;
            end
            4'hB: begin // ST
                mem_write = 1'b1;
            end
            4'hC, 4'hD, 4'hE: begin // JMP, BZ, BNZ
                is_branch = 1'b1;
            end
            4'hF: begin // HLT
                is_halt = 1'b1;
            end
            default: ;
        endcase
    end
endmodule
