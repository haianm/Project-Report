`timescale 1ns/1ps

module risc8_5stage_core (
    input  wire        clk,
    input  wire        rst,
    // Instruction Memory
    output reg  [7:0]  imem_addr,
    input  wire [15:0] imem_rdata,
    // Data Memory
    output wire        dmem_we,
    output wire [7:0]  dmem_addr,
    output wire [7:0]  dmem_wdata,
    input  wire [7:0]  dmem_rdata,
    // Memory-Mapped I/O (0xF0 - 0xFF)
    output wire        io_cs,
    output wire        io_we,
    output wire [3:0]  io_addr,
    output wire [7:0]  io_wdata,
    input  wire [7:0]  io_rdata,
    // Status
    output reg         halted
);
    localparam OP_NOP  = 4'h0, OP_ADD  = 4'h1, OP_SUB  = 4'h2, OP_AND  = 4'h3;
    localparam OP_OR   = 4'h4, OP_XOR  = 4'h5, OP_SHL  = 4'h6, OP_SHR  = 4'h7;
    localparam OP_LDI  = 4'h8, OP_ADDI = 4'h9, OP_LD   = 4'hA, OP_ST   = 4'hB;
    localparam OP_JMP  = 4'hC, OP_BZ   = 4'hD, OP_BNZ  = 4'hE, OP_HLT  = 4'hF;

    reg z_flag;

    // IF/ID
    reg [15:0] ifid_inst;
    reg        ifid_valid;

    wire [3:0] dec_op  = ifid_inst[15:12];
    wire [2:0] dec_rd  = ifid_inst[11:9];
    wire [2:0] dec_rs1 = ifid_inst[8:6];
    wire [2:0] dec_rs2 = ifid_inst[5:3];
    wire [7:0] dec_imm = ifid_inst[7:0];

    wire       cu_reg_we, cu_mem_read, cu_mem_write, cu_use_imm, cu_is_branch, cu_is_halt;
    wire [7:0] rf_rdata1, rf_rdata2;

    control_unit u_cu (
        .opcode(dec_op),
        .reg_we(cu_reg_we),
        .mem_read(cu_mem_read),
        .mem_write(cu_mem_write),
        .use_imm(cu_use_imm),
        .is_branch(cu_is_branch),
        .is_halt(cu_is_halt)
    );

    // MEM/WB
    reg [2:0] memwb_rd;
    reg [7:0] memwb_data;
    reg       memwb_we;

    regfile u_rf (
        .clk(clk),
        .rst(rst),
        .we(memwb_we),
        .waddr(memwb_rd),
        .wdata(memwb_data),
        .raddr1(dec_rs1),
        .raddr2(dec_rs2),
        .rdata1(rf_rdata1),
        .rdata2(rf_rdata2)
    );

    // ID/EX
    reg [3:0] idex_op;
    reg [2:0] idex_rd, idex_rs1, idex_rs2;
    reg [7:0] idex_imm, idex_val1, idex_val2;
    reg       idex_reg_we, idex_mem_read, idex_mem_write, idex_use_imm, idex_is_halt;
    reg       idex_valid;

    // EX/MEM
    reg [3:0] exmem_op;
    reg [2:0] exmem_rd;
    reg [7:0] exmem_alu_out, exmem_store_data;
    reg       exmem_reg_we, exmem_mem_read, exmem_mem_write, exmem_is_halt;
    reg       exmem_valid;

    wire [1:0] fwd_a, fwd_b;
    hazard_unit u_haz (
        .idex_rs1(idex_rs1),
        .idex_rs2(idex_rs2),
        .exmem_reg_we(exmem_valid && exmem_reg_we),
        .exmem_rd(exmem_rd),
        .memwb_reg_we(memwb_we),
        .memwb_rd(memwb_rd),
        .fwd_a(fwd_a),
        .fwd_b(fwd_b)
    );

    wire [7:0] mem_stage_val = (exmem_mem_read) ? (io_cs ? io_rdata : dmem_rdata) : exmem_alu_out;

    wire [7:0] alu_in_a = (fwd_a == 2'b10) ? mem_stage_val :
                          (fwd_a == 2'b01) ? memwb_data    : idex_val1;

    wire [7:0] raw_in_b = (fwd_b == 2'b10) ? mem_stage_val :
                          (fwd_b == 2'b01) ? memwb_data    : idex_val2;

    wire [7:0] alu_in_b = idex_use_imm ? idex_imm : raw_in_b;
    wire [7:0] alu_res;

    alu u_alu (
        .op(idex_op),
        .a(alu_in_a),
        .b(alu_in_b),
        .shamt(idex_imm[5:3]),
        .y(alu_res)
    );

    wire updates_z = idex_valid && (idex_op >= OP_ADD && idex_op <= OP_ADDI);
    wire next_z    = updates_z ? (alu_res == 8'h00) : z_flag;

    wire take_branch = idex_valid && (
        (idex_op == OP_JMP) ||
        (idex_op == OP_BZ  && z_flag) ||
        (idex_op == OP_BNZ && !z_flag)
    );

    // Stage 4: MEM & I/O Decode (0xF0 - 0xFF)
    wire is_mem_op = exmem_valid && (exmem_mem_read || exmem_mem_write);
    wire io_hit    = is_mem_op && (exmem_alu_out[7:4] == 4'hF);

    assign io_cs      = io_hit;
    assign io_we      = io_hit && exmem_mem_write;
    assign io_addr    = exmem_alu_out[3:0];
    assign io_wdata   = exmem_store_data;

    assign dmem_we    = exmem_valid && exmem_mem_write && !io_hit;
    assign dmem_addr  = exmem_alu_out;
    assign dmem_wdata = exmem_store_data;

    always @(posedge clk or posedge rst) begin
        if (rst) begin
            imem_addr        <= 8'h00;
            ifid_inst        <= 16'h0000;
            ifid_valid       <= 1'b0;
            idex_op          <= 4'h0;
            idex_rd          <= 3'd0;
            idex_rs1         <= 3'd0;
            idex_rs2         <= 3'd0;
            idex_imm         <= 8'h00;
            idex_val1        <= 8'h00;
            idex_val2        <= 8'h00;
            idex_reg_we      <= 1'b0;
            idex_mem_read    <= 1'b0;
            idex_mem_write   <= 1'b0;
            idex_use_imm     <= 1'b0;
            idex_is_halt     <= 1'b0;
            idex_valid       <= 1'b0;
            exmem_op         <= 4'h0;
            exmem_rd         <= 3'd0;
            exmem_alu_out    <= 8'h00;
            exmem_store_data <= 8'h00;
            exmem_reg_we     <= 1'b0;
            exmem_mem_read   <= 1'b0;
            exmem_mem_write  <= 1'b0;
            exmem_is_halt    <= 1'b0;
            exmem_valid      <= 1'b0;
            memwb_rd         <= 3'd0;
            memwb_data       <= 8'h00;
            memwb_we         <= 1'b0;
            z_flag           <= 1'b0;
            halted           <= 1'b0;
        end else if (!halted) begin
            // MEM -> WB
            memwb_rd   <= exmem_rd;
            memwb_data <= mem_stage_val;
            memwb_we   <= exmem_valid && exmem_reg_we;

            if (exmem_valid && exmem_is_halt)
                halted <= 1'b1;

            // EX -> MEM
            exmem_op         <= idex_op;
            exmem_rd         <= idex_rd;
            exmem_alu_out    <= alu_res;
            exmem_store_data <= raw_in_b;
            exmem_reg_we     <= idex_reg_we;
            exmem_mem_read   <= idex_mem_read;
            exmem_mem_write  <= idex_mem_write;
            exmem_is_halt    <= idex_is_halt;
            exmem_valid      <= idex_valid;
            z_flag           <= next_z;

            // IF/ID -> ID/EX
            if (take_branch) begin
                imem_addr  <= idex_imm;
                ifid_valid <= 1'b0;
                idex_valid <= 1'b0;
            end else begin
                imem_addr      <= imem_addr + 8'd1;
                ifid_inst      <= imem_rdata;
                ifid_valid     <= 1'b1;

                idex_op        <= dec_op;
                idex_rd        <= dec_rd;
                idex_rs1       <= dec_rs1;
                idex_rs2       <= dec_rs2;
                idex_imm       <= dec_imm;
                idex_val1      <= rf_rdata1;
                idex_val2      <= rf_rdata2;
                idex_reg_we    <= cu_reg_we;
                idex_mem_read  <= cu_mem_read;
                idex_mem_write <= cu_mem_write;
                idex_use_imm   <= cu_use_imm;
                idex_is_halt   <= cu_is_halt;
                idex_valid     <= ifid_valid;
            end
        end
    end
endmodule
